/* global QUnit */

sap.ui.require(["successfactors/masterdetail/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
