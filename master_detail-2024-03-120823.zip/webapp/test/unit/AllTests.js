sap.ui.define([
	"success_factors/master_detail/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
